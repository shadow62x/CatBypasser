from setuptools import setup, find_packages

setup(
    name="catbypasser",
    version="1.0.1",
    description="A simple bypasser",
    author="shadow62",
    author_email="strippersex8@gmail.com",
    packages=find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
    ],
    python_requires=">=3.6",
)
