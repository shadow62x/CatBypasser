# CatBypasser

CatBypasser... in python???

Yes, catbypasser is now available on python, with an open-sourced method.

## Installation

```bash
pip install catbypasser
```

## Usage

```python
from catbypasser import bypass

text = "Text here..."
BypassText = bypassed(text)
print(BypassText)  # prints the bypassed sentence.
```
